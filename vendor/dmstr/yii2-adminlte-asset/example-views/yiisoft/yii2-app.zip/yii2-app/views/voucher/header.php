<?php
use yii\helpers\Html;
?>
<div class="row">
    <div class="col-xs-12 text-center">
        <?php



        echo Html::img('uploads/logo-zanzibar.jpg',
            ['width' => '70px', 'height' => '70px', 'class' => 'img-square']);
        ?>
    </div>
</div>
<div class="row">
    <div class="col-xs-12">
        <p class="text-center">
            SERIKALI YA MAPINDUZI ZANZIBAR<br/>
            WIZARA YA KAZI, UWEZESHESHAJI, WAZEE, WANAWAKE NA WATOTO<br/>
        </p>
    </div>
</div>